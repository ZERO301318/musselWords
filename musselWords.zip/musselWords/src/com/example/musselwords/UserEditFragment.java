package com.example.musselwords;

import data.Manager;
import data.MyHelper;
import data.StateManage;
import data.UserManage;
import data.WordsManage;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class UserEditFragment extends Fragment implements OnClickListener{

	private ImageView userHeader;
	private TextView userName,name,userID,editInfos,myWords;
	private Button exit;
	
	private UserManage userManager;
	private Cursor cursor;
	
	private String id;
	
	@Override
	public void onResume() {
		StateManage state = new StateManage(getActivity());
		WordsManage words = new WordsManage(getActivity());
		int num = state.getMyWords(id);
		if(num == 0){
			myWords.setText("0������");
		}else{
			myWords.setText(num+"������");
		}
		super.onResume();
//		��ͷ����ĺ�
		if(RegisterFragment.imgView != null){
			userHeader.setImageBitmap(RegisterFragment.imgView);
		}
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_info, container,false);
		
//		ȡ����
		Bundle bundle = getArguments();
		if(bundle != null ){
			id = bundle.getString("userID");
		}
		
//		��ʼ��
		userManager = new UserManage(getActivity());
		bindWidget(view);
		initial();
		
		
		return view;
	}
	
	private void bindWidget(View v){
		userHeader = (ImageView)v.findViewById(R.id.myHead);
		userName = (TextView)v.findViewById(R.id.myName);
		name = (TextView)v.findViewById(R.id.name);
		userID = (TextView)v.findViewById(R.id.myID);
		myWords = (TextView)v.findViewById(R.id.myWords);
		
		editInfos = (TextView)v.findViewById(R.id.editInfos);
		exit = (Button)v.findViewById(R.id.exit);

		editInfos.setOnClickListener(this);
		exit.setOnClickListener(this);
	}
	
	private void initial(){
		cursor = userManager.getAll(id,null);
		userID.setText(id);
		String str = cursor.getString(cursor.getColumnIndex("NAME"));
		userName.setText(str);
		name.setText(str);
		StateManage state = new StateManage(getActivity());
		WordsManage words = new WordsManage(getActivity());
		int num = state.getMyWords(id);
		if(num == 0){
			myWords.setText("0������");
		}else{
			myWords.setText(num+"������");
		}
		
//		����ͷ��
		byte[] a = cursor.getBlob(cursor.getColumnIndex("USER_HEAD"));
		Manager manager = new Manager(getActivity());
		Bitmap bmp = manager.bytetToBmp(a);
		userHeader.setImageBitmap(bmp);
	}
	
	@Override
	public void onClick(View v) {
		Intent intent = new Intent(getActivity(),GuideActivity.class);
		switch (v.getId()) {
		case R.id.editInfos:
			intent.putExtra("userID", id);
			startActivity(intent);
			getActivity().finish();
			break;
		case R.id.exit:
//			�����û���¼״̬
			MyHelper myHelper = new MyHelper(getActivity());
			SQLiteDatabase db = myHelper.getWritableDatabase();
			db.execSQL("update USER set IS_LOGIN = 0 where USER_ID='"+id+"'");
			intent.putExtra("a", "b");
			RegisterFragment.imgView = null;
			startActivity(intent);
			getActivity().finish();
			break;
		default:
			break;
		}
	}
	
}
