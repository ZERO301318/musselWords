package com.example.musselwords;

import data.Manager;
import data.MyHelper;
import data.UserManage;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.UserManager;
import android.util.Log;
import android.view.Window;
import android.widget.Toast;

public class WelcomeActivity extends Activity{

//	启动页的延时跳转
	private static final int DELAY = 0x11;
//	延时时间--3s
	private static final int DELAY_TIME = 3000;
	
	private Handler handler;
	
	private Manager manager;
	private UserManage users;
	private Resources res;
	private MyHelper dbHelper;
	
	
	@SuppressLint("HandlerLeak") @Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.welcome);

        dbHelper = new MyHelper(this);
        manager = new Manager(this);
		users = new UserManage(this);
    	res = getResources();
		
//      初始化数据
		if(manager.isEmpty("WORDS")){
	      	if(!initial()){
	      		Toast.makeText(this, res.getString(R.string.initial_failed), Toast.LENGTH_SHORT).show();
	      	}
		}
		handler = new Handler(){
	        @SuppressLint("Recycle") @Override
	        public void handleMessage(Message msg) {
	            switch (msg.what){
	                case DELAY:// 延时3秒跳转
//	                	当没有用户注册过时
	                	if(manager.isEmpty("USER")){
	                		goActivity(GuideActivity.class);
	            		}else{
            				Intent intent = new Intent(WelcomeActivity.this, GuideActivity.class);
//	            			没有用户登录时进入登陆页面
	            			if(!users.isLogin()){
	            				intent.putExtra("a", "b");
	                			startActivity(intent);
	                		    finish();
	            			}else{
//		                		 判断引导页的选词是否选择
		            			if(!users.hasBookID()){
		            				intent.putExtra("a", "a");	
		                			startActivity(intent);
		                		    finish();
		            			}else{
				                    goActivity(MainActivity.class);
		            			}
	            			}
	            		}
	                    break;
	            }
	        }
		};
		handler.sendEmptyMessageDelayed(DELAY,DELAY_TIME);
	}
	
	/**
     * 初始化数据
     * @return false:失败 true:成功
     */
    private boolean initial(){
    	SQLiteDatabase dbWriter = dbHelper.getWritableDatabase();
    	try{
//        	单词
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('accomplish','[əˈkɑːmplɪʃ]','v.完成;实现|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('implement','[ˈɪmplɪment,ˈɪmplɪmənt]','v.实施;执行|n.工具;器具','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('accord','[əˈkɔːrd]','v.符合;一致|n.协议;条约;协调','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('commit','[kəˈmɪtɪd]','v.承诺;委托|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('abandon','[əˈbændən]','v.抛弃;放弃|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('core','[[kɔːr]]','n.核儿;(物体的)中心部分|adj.最重要的;主要的|v.去核','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('lean','[li:n]','v.依靠;靠着|adj.肉少的|n.瘦肉','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('client','[ˈklaɪənt]','n.委托人;当事人|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('decline','[ˈklaɪənt]','n.减少;下降;衰落|v.减少；下降；谢绝','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('minus','[ˈmaɪnəs]','prep.减;减去；零下|n.减号|adj.负的','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('major','[ˈmeɪdʒər]','n.主要的;重要的|v.主修','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('mayor','[ˈmeɪər]','n.镇长;市长|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('peer','[ˈpɪr]','n.身份(或地位)相同的人;同龄人|v.仔细看;端详','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('soda','[ˈsoʊdə]','n.苏打;苏大汽水|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('critic','[ˈkrɪtɪk]','n.批评家;评论家;评论员;批评者|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('rank','[ræŋk]','n.级别;军衔;军阶|v.排列;把…分等级','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('excess','[ɪkˈses]','n.超过;过度;过分|adj.超额的;额外的','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('term','[tɜːrm]','n.词语;术语;措辞|v.把…称为','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('reputation','[ˌrepjuˈteɪʃn]','n.名誉;名声|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('overwhelm','[ˌoʊvərˈwelm]','v.难以禁受;压倒;击败|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('gap','[ɡæp]','n.开口;豁口|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('pool','[pu:l]','n.水坑;水塘|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('renew','[rɪˈnuː]','v.重新开始;中止后继续|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('label','[ˈleɪbl]','n.标签;签条;标记|v.贴标签于;用标签标明','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('protein','[ˈproʊtiːn]','n.蛋白质|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('peak','[pi:k]','n.顶峰;高峰|v.达到高峰','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('stuff','[stʌf]','n.念头;东西;基本特征|v.填满;装满','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('contrary','[ˈkɑːntreri]','n.相反的事实(或事情、情况)|adj.与之相异的;相对立的','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('sway','[sweɪ]','v.(使)摇摆，摇动;说服|n.摇摆;摆动;统治','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('switch','[swɪtʃ]','n.(电路的)开关;闸代理|v.(使)改变;转变','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('ability','[əˈbɪləti]','n.能力;才能;本领|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('vision','[ˈvɪʒn]','n.视力;视野;想象|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('convert','[kənˈvɜːrt ]','v.(使)转变;转换;转化|n.皈依者','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('compare','[kəmˈper]','n.比较;对比|v.比较;对比','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('hazard','[ˈhæzərd]','n.危险;危害|v.冒失地提出;冒险猜测','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('pinch','[pɪntʃ]','v.拧;捏;掐|n.捏;掐;拧','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('crack','[kræk]','v.破裂;裂开;断裂|n.裂纹;裂缝;缝隙|adj.训练有素的','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('crash','[kræʃ]','n.撞车;碰撞;相撞|v.碰撞;撞击','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('logic','[ˈlɑːdʒɪk]','n.思维方式;解释方法|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('utter','[ˈʌtər]','adj.完全的;十足的|v.出声;说;讲','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('inward','[ˈɪnwərd]','adj.内心的;精神的|adv.向内;向中心','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('utmost','[ˈʌtmoʊst]','adj.最大的;极度的|v.最大量;最大限度','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('interrupt','[ˌɪntəˈrʌpt]','v.插嘴;打扰;打岔;使暂停|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('exterior','[ɪkˈstɪriər]','n.外观;表面|adj.外面的;外部的','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('assess','[əˈses]','v.评估;评定(性质、质量)|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('beam','[biːm]','n.光线;(电波的)波束|v.笑容满面;眉开眼笑;发射(电波)','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('cue','[kju:]','n.暗示;提示;信号|v.给(某人)暗示(或提示)','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('dim','[dɪm]','adj.暗淡的;昏暗的|v.(使)变暗淡;变微弱','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('ratio','[ˈreɪʃioʊ]','n.比率;比例|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('faculty','[ˈfæklti]','n.官能; 天赋|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('decent','[ˈdiːsnt]','adj.像样的;相当不错的|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('equicvalent','[ɪˈkwɪvələnt]','adj.相等的;相同的|n.相等的东西;等量','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('saint','[seɪnt]','n.圣人;圣徒;|','1')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('sacred','[ˈseɪkrɪd]','adj.上帝的;神的;神圣的|','1')");
//        	2
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('setback','[ˈsetbæk]','n.退步;挫折|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('gossip','[ˈɡɑːsɪps]','n.流言蜚语;闲话|v.散播','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('discard','[dɪskɑːrd]','v.丢弃;丢掉|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('ignite','[ɪɡˈnaɪt]','v.(使)着火;点燃|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('propel','[ˈprəˈpel]','v.推动;驱动;推进|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('lure','[lure]','v.劝诱;引诱|n.吸引力;诱惑力','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('artery','[ˈɑːrtəri]','n.动脉;干线|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('splash','[splæʃ]','v.泼洒;哗啦哗啦地溅|n.落水声;溅泼声','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('overthrow','[ˌoʊvərˈθroʊ ]','n.推翻;打倒|v.推翻;打倒','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('notion','[ˈnoʊʃn]','n.观念;信念|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('ensure','[ɪnˈʃʊr]','v.保证;担保|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('acute','[əˈkjuːt]','adj.十分严重的;(疾病)急性的|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('repression','[rɪˈpreʃn]','n.压制;镇压;抑制|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('shipment','[ˈʃɪpmənt]','n.运输;运送;装运|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('feeble','[ˈfiːbl]','adj.虚弱的;衰弱的;无效的|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('chord','[kɔːrd]','n.和弦;和音;弦|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('premier','[prɪˈmɪr]','adj.首要的;最著名的|n.首相;总理','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('casual','[ˈkæʒuəl]','adj.不经意的;无忧无虑的|n.便装;便鞋','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('gear','[ɡɪrs]','n.排挡;齿轮;传动装置|v.换挡;(使)搭配','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('cellar','[ˈselər]','n.地窖;地下室|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('reclaim','[rɪˈkleɪm]','v.取回;拿回;要求归还;开垦|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('breed','[briːd]','n.品种(尤指人工培育的狗、猫或牲畜)|v.交配繁殖;饲养','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('slip','[slɪp]','v.滑倒;滑跤;滑落|n.差错;疏漏;纰漏','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('owe','[oʊ]','v.欠(债);欠(账);欠(情);归因于|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('complaint','[kəmˈpleɪnt]','n.不满的原因;抱怨;埋怨|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('stability','[stəˈbɪləti]','n.稳定(性);稳固(性)|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('flare','[fler]','n.(短暂的)旺火;(摇曳的)光|v.(短暂)烧旺;(摇曳着)燃烧','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('reaction','[riˈækʃn]','n.反应;回应;(对旧观念等的)抗拒|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('entail','[ɪnˈteɪl]','v.牵涉;需要|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('dodge','[dɑːdʒ]','v.闪开;躲开;避开|n.推脱的计策;逃避的诡计','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('stagger','[ˈstæɡər]','v.摇摇晃晃地走;蹒跚;踉跄|n.摇晃;一种不稳定形式','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('ego','[ˈiːɡoʊ]','n.自我价值感;自我|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('radical','[ˈrædɪkl]','n.激进分子;游离基|adj.根本的;彻底的;完全的','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('rot','[rɑːt]','n.腐烂;腐败变质|v.(使)腐烂;败变质','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('grim','[ɡrɪm]','adj.严肃的;坚定的;阴冷的|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('prone','[ˈsetbæk]','adj.易于遭受;有做(坏事)的倾向|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('startle','[ˈstɑːrtl]','v.使惊吓;使吓一跳;使大吃一惊|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('expose','[ɪkˈspoʊz]','n.陈述;阐述|v.暴露;显露;露出','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('initial','[ɪˈnɪʃl]','adj.最初的;开始的|n.(名字的)首字母;(全名的)首字母|v.用姓名的首字母作标记(或签名)于','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('status','[ˈsteɪtəs]','n.法律地位(或身份);地位;身份|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('abnormal','[æbˈnɔːrml]','adj.不正常的;反常的|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('stereo','[ˈsterioʊ]','n.立体声音响(或录音机等)|adj.立体声的;有立体感的','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('option','[ˈɑːpʃn]','n.可选择的事物;选择 选择权|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('stern','[stɜːrn]','adj.严厉的;苛刻的;要求别人服从的|n.船尾','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('crime','[kraɪm]','n.犯罪活动;不法行为|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('sticky','[ˈstɪki]','n.告事贴|adj.黏(性)的;一面带黏胶的','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('patron','[ˈpeɪtrən]','n.(艺术家的)赞助人;资助者|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('dub','[dʌb]','n.(西印度群岛的)强节奏音乐|v.把…戏称为;给…起绰号','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('desire','[dɪˈzaɪər]','n.愿望;欲望;渴望|v.渴望;期望;想望','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('bamboo','[ˌbæmˈbuː]','n.竹;竹子|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('heel','[hiːl]','n.足跟;脚后跟;(袜子等的)后跟|v.给(鞋等)修理后跟;倾侧','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('romance','[ˈroʊmæns]','n.浪漫史，爱情关系|v.虚构(故事);渲染','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('flutter','[ˈflʌtər]','v.(使)飘动;挥动|n.振动;飘动;挥动;颤动','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('fiction','[ˈfɪkʃn]','n.小说;虚构的事|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('cute','[kjuːt]','adj.可爱的;漂亮迷人的;有性吸引力的|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('decent','[ˈdiːsnt]','adi.像样的;相当不错的;尚好的;正派的|','2')");
        	dbWriter.execSQL("insert into WORDS ('SPELLING','IPA','MEANNING','BOOK_ID') values ('stable','[ˈsteɪbl]','adj.稳定的;稳固的|n.马厩;(养马作特定用途的)养马场|v.使(马)入厩;把(马)拴在马厩','2')");
        	
    	}catch(Exception e){
    		System.out.print(e.getMessage());
    		Log.d("TAG", e.getMessage());
    		return false;
    	}finally{
    		dbWriter.close();
    	}
    	return true;
    }
    
	
	private void goActivity(Class activity) {
		 startActivity(new Intent(WelcomeActivity.this, activity));
	     finish();// 销毁当前活动界面
	 } 
}
