package com.example.musselwords;

import java.util.Locale;

import data.MyHelper;
import data.StateManage;
import data.UserManage;
import data.WordsManage;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ReviewFragment extends Fragment implements OnClickListener{

	private Cursor cursor;
	private UserManage userManager;
	private WordsManage wordsManager;
	private StateManage stateManager;
	private String userID;
	private int bookID;
	
	private TextView words,speaker,mean;
	private Button know,indistinct,unknow;
	
	private String[] means;
	private TextToSpeech speach;
	private boolean bool = false;
	private int index = 1;
	private SharedPreferences sp;
		
	
	
//	ˢ������
	@Override
	public void onResume() {
		Cursor tmp = userManager.getAll(userID, null);
		bookID = tmp.getInt(tmp.getColumnIndex("BOOK_ID"));
		cursor = wordsManager.getAll(bookID,false);
		if(stateManager.isNew(userID)){
			index = 1;
		}
		cursor.moveToPosition((index-1));
		show();
		super.onResume();
	}

	@Override
	public void onStart() {
		speach.speak(words.getText().toString(), TextToSpeech.QUEUE_FLUSH, null);
		super.onStart();
	}



	@Override
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_review, container,false);
		bindWidgets(view);

//		ȡ����
		Bundle bundle = getArguments();
		if(bundle != null ){
			userID = bundle.getString("userID");
		}
		initial();
		
		return view;
	}
	
	private void bindWidgets(View view){
		words = (TextView)view.findViewById(R.id.words);
		speaker = (TextView)view.findViewById(R.id.speaker);
		mean = (TextView)view.findViewById(R.id.mean);
		
		know = (Button)view.findViewById(R.id.know);
		indistinct = (Button)view.findViewById(R.id.indistinct);
		unknow = (Button)view.findViewById(R.id.unknow);
		
		speaker.setOnClickListener(this);
		know.setOnClickListener(this);
		indistinct.setOnClickListener(this);
		unknow.setOnClickListener(this);
	}

	private void initial(){
		
		wordsManager = new WordsManage(getActivity());
		userManager = new UserManage(getActivity());
		stateManager = new StateManage(getActivity());
		Cursor tmp = userManager.getAll(userID, null);
		bookID = tmp.getInt(tmp.getColumnIndex("BOOK_ID"));
		cursor = wordsManager.getAll(bookID,false);

//		ȡ����
		sp = getActivity().getSharedPreferences("index", Context.MODE_PRIVATE);
		index = sp.getInt("i", -1);

//		��û�б���
		if(index == -1){
			index = 1;
		}
		cursor.moveToPosition((index-1));
		show();
		
		speach = new TextToSpeech(getActivity(), new TextToSpeech.OnInitListener() {
			
			@Override
			public void onInit(int status) {
				if(status == speach.SUCCESS){
					int result = speach.setLanguage(Locale.US);
					if(result != TextToSpeech.LANG_COUNTRY_AVAILABLE && result != TextToSpeech.LANG_AVAILABLE){
						Log.d("TAG", "TTS IS FULLY");
					}
				}
			}
		});
	}
	
	public void show(){
		words.setText(cursor.getString(cursor.getColumnIndex("SPELLING")));
		speaker.setText(cursor.getString(cursor.getColumnIndex("IPA")));
		means = cursor.getString(cursor.getColumnIndex("MEANNING")).split("\\|");
		
		String str = "";
		
		for(int i=0; i<means.length; i++){
			if(i == 0){
				str += means[i];
			}else{
				str += "\n\n"+means[i];
			}
		}
		mean.setText(str);
	}
	
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.know:
			updateState(2);
			break;
		case R.id.indistinct:
			updateState(1);
			break;
		case R.id.unknow:
			updateState(0);
			break;
		default:
			break;
		}
		speach.speak(words.getText().toString(), TextToSpeech.QUEUE_ADD, null);
	}

	public void updateState(int i){
		int wordID = cursor.getInt(cursor.getColumnIndex("WORD_ID"));
		stateManager.update(wordID,i,false);
		index++;
//		���������һ������ʱ
		if(!cursor.isAfterLast() && index < (cursor.getCount()+1)){
			cursor.moveToNext();
			show();
		}else{
			index--;
			Toast.makeText(getActivity(), "��ϲ�㱳���ˣ�", Toast.LENGTH_SHORT).show();
			selectType();
		}
	}
	
	
	
	@Override
	public void onStop() {
//		���汳���ʵ�ID
		sp = getActivity().getSharedPreferences("index", Context.MODE_PRIVATE);
		Editor edit = sp.edit();
		edit.putInt("i", index);
		edit.commit();
		
		super.onStop();
	}

	@Override
	public void onDestroy() {
		if(speach != null){
			speach.shutdown();
		}
		super.onDestroy();
	}
	
//	������
	public void selectType(){
		Builder builder = new Builder(getActivity());
		final AlertDialog dialog = builder.create();
		View view = View.inflate(getActivity(), R.layout.select_review,null);
		TextView chooseFor = (TextView)view.findViewById(R.id.chooseFor);
		TextView reviewAgain = (TextView)view.findViewById(R.id.reviewAgain);

		final MyHelper myHelper = new MyHelper(getActivity());
//		ѡ��statue<=1�ĵ���
		chooseFor.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				SQLiteDatabase db = myHelper.getWritableDatabase();
				db.execSQL("update STATE set REVIEW_TIMES = 0 where KNOW_STATUE<=1 and USER_ID = '"+userID+"'");
				db.execSQL("update STATE set KNOW_STATUE = 0 where REVIEW_TIMES = 0 and USER_ID = '"+userID+"'");
				db.close();
				cursor = wordsManager.getAll(bookID,true);
				index = 1;
				show();
				dialog.dismiss();
			}
		});
		
//		���е��ʻ�ԭԭʼ״̬
		reviewAgain.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				SQLiteDatabase db = myHelper.getWritableDatabase();
				db.execSQL("update STATE set REVIEW_TIMES = 0,KNOW_STATUE = 0 where USER_ID = "+userID);
				db.close();
				cursor = wordsManager.getAll(bookID,false);
				index = 1;
				show();
				dialog.dismiss();
			}
		});
		dialog.setView(view);
		dialog.show();
	}
}
