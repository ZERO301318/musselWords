package com.example.musselwords;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;

public class MainActivity extends FragmentActivity implements OnCheckedChangeListener{
	
	private Fragment a,b,c,d;
	
	private RadioGroup rg;
	private RadioButton tab01,tab02,tab03,tab04;
	
	private String userID = null,tag = null;
	
	public SharedPreferences sp;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        
        Intent intent = getIntent();
        userID = intent.getStringExtra("userID");
        tag = intent.getStringExtra("TAG");
        if(userID == null){
    		sp = this.getSharedPreferences("userID", Context.MODE_PRIVATE);
    		userID = sp.getString("userID", "wrong");
    	}
        
//        绑定控件
        bindWidgets();

      if(tag == null){
//        默认显示单词
    	  setSelect(0);
      }else{
//        若是从编辑页面过来
    	  setSelect(3);
    	  tab04.setChecked(true);
      }
       
    }
    
//    绑定控件
    public void bindWidgets(){
    	rg = (RadioGroup)findViewById(R.id.tabs);
    	tab01 = (RadioButton)findViewById(R.id.review);
    	tab02 = (RadioButton)findViewById(R.id.dictation);
    	tab03 = (RadioButton)findViewById(R.id.books);
    	tab04 = (RadioButton)findViewById(R.id.account);
    	rg.setOnCheckedChangeListener(this);
    			
    }  
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
//    底部菜单栏背景切换
	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {
		switch (checkedId) {
		case R.id.review:
			setSelect(0);
			break;
		case R.id.dictation:
			setSelect(1);
			break;
		case R.id.books:
			setSelect(2);
			break;
		case R.id.account:
			setSelect(3);
			break;
		default:
			break;
		}
	}
	
	private void setSelect(int i) {
		FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction transaction = fm.beginTransaction();
//      先隐藏所有fragment
        hideAllFragment(transaction);
		Bundle bundle = new Bundle();
		bundle.putString("userID", userID);
        switch (i) {
        case 0:
        	if (a == null) {
        		a = new ReviewFragment();
        		a.setArguments(bundle);
        		transaction.add(R.id.container, a);
	        }else {
	            a.onResume();
	            transaction.show(a);
	        }
            break;
        case 1:
        	if (b == null) {
        		b = new DictationFragment();
        		b.setArguments(bundle);
        		transaction.add(R.id.container, b);
	        }else {
	            b.onResume();
	            transaction.show(b);
	        }
            break;
        case 2:
        	if (c == null) {
        		c = new BookFragment();
        		c.setArguments(bundle);
        		transaction.add(R.id.container, c);
	        }else {
	        	c.onResume();
	            transaction.show(c);
	        };
            break;
        case 3:
        	if (d == null) {
        		d = new UserEditFragment();
        		d.setArguments(bundle);
        		transaction.add(R.id.container, d);
	        }else {
	            transaction.show(d);
	            if(tag == null){
		            d.onResume();
	            }else{
	            	tag = null;
	            }
	        }
            break;

        default:
            break;
        }
        transaction.commit();//提交事务
    }

    /*
     * 隐藏所有的Fragment
     * */
    private void hideAllFragment(FragmentTransaction transaction) {
        if (a != null) {
            transaction.hide(a);
        }
        if (b != null) {
            transaction.hide(b);
        }
        if (c != null) {
            transaction.hide(c);
        }
			
        if (d != null) {
            transaction.hide(d);
        }
        
    }
    
}
