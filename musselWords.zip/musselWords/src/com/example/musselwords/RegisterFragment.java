package com.example.musselwords;

import java.io.ByteArrayOutputStream;

import data.Manager;
import data.MyHelper;
import data.UserManage;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterFragment extends Fragment implements OnClickListener{
	public static Bitmap imgView = null;
	
	private UserManage userManage;
	private Cursor cursor;
	
	private ImageView img;
	private EditText newName,newPass,rePass,pass;
	private TextView t1,t2,t3,backIcon;
	private Button resign;
	private Resources res;
	
	private  String userID;
	private boolean isEdit  = false;
	
	@Override
	public void onResume() {
		super.onResume();
//		��ͷ����ĺ�
		if(imgView != null){
			Log.d("wrong", "not null");
			img.setImageBitmap(imgView);
		}
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_register, container,false);

		if(imgView != null){
			img.setImageBitmap(imgView);
		}
		
		try{
			userID = getArguments().getString("userID");
		}catch(NullPointerException e){
			userID = null;
		}
		
//		��ʼ��
		userManage = new UserManage(getActivity());
		res = getResources();
		bindWidget(view);
		
//		�����༭ʱ
		if(userManage.isLogin()){
			initial();
			isEdit = true;
		}
		
		return view;
	}
	
	public void bindWidget(View view){
		img = (ImageView)view.findViewById(R.id.pic);
		
		newName = (EditText)view.findViewById(R.id.newName);
		newPass = (EditText)view.findViewById(R.id.newPass);
		rePass = (EditText)view.findViewById(R.id.rePass);
		
		resign = (Button)view.findViewById(R.id.resign);
		resign.setOnClickListener(this);
		img.setOnClickListener(this);
		
//		�޸�string
		t1 = (TextView)view.findViewById(R.id.t1);
		t2 = (TextView)view.findViewById(R.id.t2);
//		invisible
		pass = (EditText)view.findViewById(R.id.pass);
		t3 = (TextView)view.findViewById(R.id.t3);
		backIcon  = (TextView)view.findViewById(R.id.backInfo);
	}

	private void initial(){
//		���ÿɼ�
		t3.setVisibility(TextView.VISIBLE);
		pass.setVisibility(EditText.VISIBLE);
		backIcon.setVisibility(TextView.VISIBLE);
		backIcon.setOnClickListener(this);
//		������ʾ��
		t1.setText(res.getString(R.string.pre_pass));//ԭ����
		t2.setText(res.getString(R.string.newPass));//������
		t3.setText(res.getString(R.string.repass));//ȷ������
		resign.setText(res.getString(R.string.confirm_edit));
		
		cursor = userManage.getAll(userID, null);
		newName.setText(cursor.getString(cursor.getColumnIndex("NAME")));

//		����ͷ��
		byte[] a = cursor.getBlob(cursor.getColumnIndex("USER_HEAD"));
		Manager manager = new Manager(getActivity());
		Bitmap bmp = manager.bytetToBmp(a);
		img.setImageBitmap(bmp);
	}
	
	
	@Override
	public void onClick(View v) {
		String a,b,c;
		byte[] pic = null;
		
//		����Ĭ��ֵ
		if(imgView == null){
			imgView = BitmapFactory.decodeResource(getResources(), R.drawable.default_head);
			pic = saveImg();
		}

		a = String.valueOf(newName.getText());
		b = String.valueOf(newPass.getText());
		c = String.valueOf(rePass.getText());
		
		switch (v.getId()) {
		case R.id.backInfo:
			String preName = cursor.getString(cursor.getColumnIndex("NAME"));
//			������δ�޸Ĺ�ʱ
			if(!b.equals("") || !c.equals("") || !pass.getText().toString().equals("") || !a.equals(preName) || imgView != null){
				select();
			}else{
				Intent intent = new Intent(getActivity(),MainActivity.class);
				intent.putExtra("TAG", "editBack");
				startActivity(intent);
				getActivity().finish();
			}
			break;
		case R.id.resign:
//			�û�����Ϊ��
			if(a.equals("")){
				Toast.makeText(getActivity(), getResources().getString(R.string.name_empty), Toast.LENGTH_SHORT).show();
//				ǰ�������ղ���Ϊ��
			}else{
//				���޸��û���Ϣʱ
				if(isEdit){
//					ԭ���벻��Ϊ��
					if(b.equals("")){
						Toast.makeText(getActivity(), getResources().getString(R.string.emptyOldPass), Toast.LENGTH_SHORT).show();
					}else{
//						У��ԭ�����Ƿ�һ��
						if(userManage.checkUser(userID, b, false)){
//							��û���޸�����ʱ
							String d = pass.getText().toString();
							if(c.equals("") && d.equals("")){
								submit(a, null, pic);
							}else{
								if(c.equals(d)){
									submit(a,c,pic);
								}else{
									rePass.setText("");
									pass.setText("");
									Toast.makeText(getActivity(), getResources().getString(R.string.pass_notSame), Toast.LENGTH_SHORT).show();
								}
							}
						}else{
							newPass.setText("");
							rePass.setText("");
							pass.setText("");
							Toast.makeText(getActivity(), getResources().getString(R.string.wrong_pass), Toast.LENGTH_SHORT).show();
						}
					}
				}else{
					if(b.equals("") || c.equals("")){
						Toast.makeText(getActivity(), getResources().getString(R.string.pass_empty), Toast.LENGTH_SHORT).show();
					}else if(b.equals(c)){
//						�û����Ƿ����ظ�
						if(userManage.isRepeat(null,a,true)){
//							�����û�
							if(userManage.insert(a, b, pic)){
								
//								ȡ�û�id
								cursor = userManage.getAll(null, a);
								FragmentManager fm = getFragmentManager();
								FragmentTransaction ft = fm.beginTransaction();
								BookFragment choose = new BookFragment();
								userID = cursor.getString(cursor.getColumnIndex("USER_ID"));
//								����userID
								SharedPreferences sp = getActivity().getSharedPreferences("userID", Context.MODE_PRIVATE);
								Editor edit = sp.edit();
								edit.putString("userID", userID).commit();
								
//								����
								Bundle bundle = new Bundle();
								bundle.putString("userID", userID);
								choose.setArguments(bundle);
								ft.hide(this);
								ft.replace(R.id.guide_container,choose);
								ft.addToBackStack(null).commit();
								
//								����islogin=1��ʾ���û�����
								MyHelper myHelper = new MyHelper(getActivity());
								SQLiteDatabase db = myHelper.getWritableDatabase();
								db.execSQL("update USER set IS_LOGIN = 1 where USER_ID='"+userID+"'");
								db.close();
							}else{
								Toast.makeText(getActivity(), getResources().getString(R.string.wrong_resign), Toast.LENGTH_SHORT).show();
							}
						}else{
							newName.setText("");
							showWrongInfo();
						}
					}else{
						newPass.setText("");
						rePass.setText("");
						Toast.makeText(getActivity(), getResources().getString(R.string.pass_notSame), Toast.LENGTH_SHORT).show();
					}
				}
			}
			break;
		case R.id.pic:
			selectType();
			break;
		default:
			break;
		}
	}
	
//	��ʼ����
	public void submit(String a, String c,byte[] pic){
//		δ�޸�ͷ��ʱ
		if(imgView == null){
			pic = null;
			Log.d("wrong", "null");
		}
//		��֤�û����Ƿ��ظ�
		if(userManage.isRepeat(userID, a, false)){
			if(userManage.update(userID, a, c, pic)){
				Intent intent = new Intent(getActivity(),MainActivity.class);
				intent.putExtra("TAG", "editBack");
				startActivity(intent);
				getActivity().finish();
				Toast.makeText(getActivity(), getResources().getString(R.string.edit_success), Toast.LENGTH_SHORT).show();
			}else{
				Toast.makeText(getActivity(), getResources().getString(R.string.edit_failure), Toast.LENGTH_SHORT).show();
			}
		}else{
			newName.setText("");
			Toast.makeText(getActivity(), getResources().getString(R.string.wrong_account), Toast.LENGTH_SHORT).show();
		}
	}
	
//	�����Ƿ��뿪�༭
	public void select(){
		final AlertDialog mDialog = new AlertDialog.Builder(getActivity()).create();
		mDialog.setTitle("��ʾ");
		mDialog.setMessage("ȷ��Ҫ�뿪��");
		DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				if(which == DialogInterface.BUTTON_POSITIVE){
					Intent intent = new Intent(getActivity(),MainActivity.class);
					intent.putExtra("TAG", "editBack");
					startActivity(intent);
					getActivity().finish();
				}
			}
		};
		mDialog.setButton(DialogInterface.BUTTON_NEGATIVE,"ȡ��",listener);
		mDialog.setButton(DialogInterface.BUTTON_POSITIVE,"ȷ��",listener);
		mDialog.dismiss();
		mDialog.show();
	}
	
//	��Ƭ������
	public void selectType(){
		Builder builder = new Builder(getActivity());
		final AlertDialog dialog = builder.create();
		View view = View.inflate(getActivity(), R.layout.select_dialog,null);
		TextView select_gallery = (TextView)view.findViewById(R.id.select_gallery);
		TextView select_camera = (TextView)view.findViewById(R.id.select_camera);
		
//		�򿪱������ѡ��ͷ��
		select_gallery.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent(getActivity(),AlbumActivity.class);
				intent.putExtra("photo_width", img.getWidth());   // ����������ɺ���ʾ��Ƭʱ�Ŀ���
				intent.putExtra("photo_height", img.getHeight()); // ����������ɺ���ʾ��Ƭʱ�ĸ߶�
				startActivity(intent);
				dialog.dismiss();
			}
		});
		
//		���ջ�ȡͷ��
		select_camera.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(), CameraActivity.class);
				intent.putExtra("photo_width", img.getWidth());   // ����������ɺ���ʾ��Ƭʱ�Ŀ���
				intent.putExtra("photo_height", img.getHeight()); // ����������ɺ���ʾ��Ƭʱ�ĸ߶�
				startActivity(intent);
				dialog.dismiss();
			}
		});
//		
		dialog.setView(view);
		dialog.show();
	}
	
	
//	ע��ʧ����ʾ
	public void showWrongInfo(){
		Builder builder = new Builder(getActivity());
		final AlertDialog dialog = builder.create();
		View view = View.inflate(getActivity(), R.layout.wrong_resign,null);
		TextView confirm = (TextView)view.findViewById(R.id.cf);
		
		confirm.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});
		dialog.setView(view);
		dialog.show();
	}
	
	public byte[] saveImg(){
		byte[] pic = null;
		int size = imgView.getWidth() * imgView.getHeight() * 4;
		// ����һ���ֽ����������,���Ĵ�СΪsize
		ByteArrayOutputStream baos = new ByteArrayOutputStream(size);
		try {
			// ����λͼ��ѹ����ʽ������Ϊ100%���������ֽ������������
			imgView.compress(Bitmap.CompressFormat.PNG, 100, baos);
			// ���ֽ����������ת��Ϊ�ֽ�����byte[]
			pic = baos.toByteArray();
			// �ر�������Ƭ�Ѿ�������ֽ�����
			baos.close();
			// ��������Ƭ����Ӧ��bitmap�е�����
			imgView.recycle();
			imgView = null;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return pic;
	}
}
