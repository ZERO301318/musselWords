package com.example.musselwords;

import data.BooksManage;
import data.Manager;
import data.StateManage;
import data.UserManage;
import data.WordsManage;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class BookFragment extends Fragment implements OnClickListener{

	private RadioGroup books;
	private RadioButton book01,book02;
	private Button confirm;
	private BooksManage booksManager;
	private WordsManage words;
	private StateManage state;
	private Manager manager;

	private Resources res;
	private String userID;
	private boolean bool = false;
	
	
	
	@Override
	public void onResume() {
		UserManage users = new UserManage(getActivity());
		Cursor cursor = users.getAll(userID, null);
		int book = cursor.getInt(cursor.getColumnIndex("BOOK_ID"));
		String str1,str2;
		str1 = str2 = "";
		if(book == 1){
			str1 += " (�ҵĴ���)";
			book01.setChecked(true);
		}
		if(book == 2){
			str2 += " (�ҵĴ���)";
			book02.setChecked(true);
		}
		super.onResume();
	}

	@Override
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_choose, container,false);
		
		booksManager = new BooksManage(getActivity());
		words = new WordsManage(getActivity());
		state = new StateManage(getActivity());
		manager = new Manager(getActivity());
		
		try{
			userID = getArguments().getString("userID");
		}catch(NullPointerException e){
			userID = null;
		}
		
//		���Ƿ�Ϊ��
		if(manager.isEmpty("BOOKS")){
			initial();
		}
//		�ж��Ƿ���Main�е�ѡ��
		UserManage user = new UserManage(getActivity());
		if(user.hasBookID()){
			bool = true;
		}
		bindWidgets(view);
		return view;
	}
	
	public void bindWidgets(View view){
		
		books = (RadioGroup)view.findViewById(R.id.choose_books);
		confirm = (Button)view.findViewById(R.id.confirm_choice);
		confirm.setOnClickListener(this);
		book01 = (RadioButton)view.findViewById(R.id.book01);
		book02 = (RadioButton)view.findViewById(R.id.book02);
		String str1 = booksManager.getName(1)+"("+booksManager.numOfWords(1)+")";
		String str2 = booksManager.getName(2)+"("+booksManager.numOfWords(2)+")";
		if(bool){
			UserManage users = new UserManage(getActivity());
			Cursor cursor = users.getAll(userID, null);
			int book = cursor.getInt(cursor.getColumnIndex("BOOK_ID"));
			if(book == 1){
				str1 += " (�ҵĴ���)";
				book01.setChecked(true);
			}
			if(book == 2){
				str2 += " (�ҵĴ���)";
				book02.setChecked(true);
			}
			
		}
		book01.setText(str1);
		book02.setText(str2);
	}
	
	public void initial(){
		booksManager.insert("��ѧӢ���ļ��ʻ�", booksManager.numOfWords(1));
		booksManager.insert("��ѧӢ�������ʻ�", booksManager.numOfWords(2));
	}

	@Override
	public void onClick(View v) {
		if(!bool){
			update();
		}else{
//			�����û�����󽫻�ɾ��ԭ�����м�¼
			final AlertDialog mDialog = new AlertDialog.Builder(getActivity()).create();
			mDialog.setTitle("����");
			mDialog.setMessage("�޸ĺ󽫻�ɾ��ԭ�е����б����ʼ�¼��ȷ��Ҫ�޸���");
			DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
//				�����û�����
				@Override
				public void onClick(DialogInterface dialog, int which) {
					if(which == DialogInterface.BUTTON_POSITIVE){
						update();
					}
				}
			};
			mDialog.setButton(DialogInterface.BUTTON_NEGATIVE,"ȡ��",listener);
			mDialog.setButton(DialogInterface.BUTTON_POSITIVE,"ȷ��",listener);
			mDialog.dismiss();
			mDialog.show();
		}
	}
	
	public void update(){
		String str1 = booksManager.getName(1)+"("+booksManager.numOfWords(1)+")";
		String str2 = booksManager.getName(2)+"("+booksManager.numOfWords(2)+")";
		int choosed = books.getCheckedRadioButtonId();
		res = getResources();
		if(choosed == R.id.book01){
			if(booksManager.updateBookID(userID, 1)){
				if(!bool){
					initialState(1);
				}else{
					updateBook(1);
					Toast.makeText(getActivity(), res.getString(R.string.choose_success), Toast.LENGTH_SHORT).show();
					book01.setText(str1+" (�ҵĴ���)");
					book02.setText(str2);
				}
			}else{
				Toast.makeText(getActivity(), res.getString(R.string.choose_failed), Toast.LENGTH_SHORT).show();
			}
		}else{
			if(booksManager.updateBookID(userID, 2)){
				if(!bool){
					initialState(2);
				}else{
					updateBook(2);
					Toast.makeText(getActivity(), res.getString(R.string.choose_success), Toast.LENGTH_SHORT).show();
					book02.setText(str2+" (�ҵĴ���)");
					book01.setText(str1);
				}
			}else{
				Toast.makeText(getActivity(), res.getString(R.string.choose_failed), Toast.LENGTH_SHORT).show();
			}
		}
	}
	
//	��ʼ��state��
	public void initialState(int i){
		if(state.initial(userID, words.getAll(i,false))){
			goHome();
			Toast.makeText(getActivity(), res.getString(R.string.choose_success), Toast.LENGTH_SHORT).show();
		}else{
			Log.d("FAILED", "WRONG!!!!");
		}
	}
	
	public void goHome(){
		Intent intent = new Intent(getActivity(),MainActivity.class);
		intent.putExtra("userID", userID);
		startActivity(intent);
		getActivity().finish();
	}
	
	public void updateBook(int i){
		state.deleteAll(userID);
		state.initial(userID, words.getAll(i,false));
	}
	
}
