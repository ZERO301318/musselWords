package com.example.musselwords;

import android.app.Activity;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.MediaStore.Images.Media;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class AlbumActivity extends Activity {
	private int display_width = -1;
	private int display_height = -1;
	private Bitmap img = null;
	private ImageView photo;
	private Button prev, next, exit, select;
	private Cursor cur;
	private int imageIndex;
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    // TODO Auto-generated method stub
	    setContentView(R.layout.album);
		setTitle("�����Ƭ��ѡ����Ƭ");
		display_width = getIntent().getIntExtra("photo_width", 0);
		display_height = getIntent().getIntExtra("photo_height", 0);
		
		photo = (ImageView) findViewById(R.id.pics);
		prev = (Button) findViewById(R.id.btn_pre);
		next = (Button) findViewById(R.id.btn_next);
		exit = (Button) findViewById(R.id.out);
		select = (Button) findViewById(R.id.select);
		
		// ֻ��Ҫ��Ƭ�Ĵ洢·��
 		String columns[] = new String[] { Media.DATA };
 		// ��ѯ���е���Ƭ����¼��
		cur = this.getContentResolver().query(Media.EXTERNAL_CONTENT_URI,
				columns, null, null, null);
		// �õ�����������ֵ
		imageIndex = cur.getColumnIndex(Media.DATA);
		// ��ʾ��һ����Ƭ
		if (cur.moveToFirst()) {
			showImage();
		} else { // ��ǰý�����û���κ���Ƭ��
			prev.setEnabled(false);
			next.setEnabled(false);
			select.setEnabled(false);
			
			Toast.makeText(this, "ý�����û����Ƭ��", Toast.LENGTH_SHORT).show();
		}
		
		prev.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				readPre(); // ��ʾǰһ����Ƭ
			}
		});
		next.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				readNext(); // ��ʾ��һ����Ƭ
			}
		});
		select.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (RegisterFragment.imgView != null) {
					RegisterFragment.imgView.recycle();
					RegisterFragment.imgView = null;
				}
				RegisterFragment.imgView = img;
				cur.close();
				finish();
			}
		});
		exit.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				cur.close();
				img.recycle();
				img = null;
				finish();
			}
		});
	}
	
	private void readPre() {
		cur.moveToPrevious();
		if (!cur.isBeforeFirst()) {
			showImage();
		} else {
			Toast.makeText(this, "�Ѿ��ǵ�һ����Ƭ��", Toast.LENGTH_SHORT).show();
			cur.moveToNext();
		}
	}

	private void readNext() {
		cur.moveToNext();
		if (!cur.isAfterLast()) {
			showImage();
		} else {
			Toast.makeText(this, "�Ѿ������һ����Ƭ��", Toast.LENGTH_SHORT).show();
			cur.moveToPrevious();
		}
	}
	
	/**
	 * ��ʾͼƬ��Ϣ
	 */
	private void showImage() {
		String path = cur.getString(imageIndex);  // ��ȡͼƬ�洢��λ����Ϣ
		if (img != null) {                        // ��ʾ��Ƭǰ������һ����
			img.recycle();                        // ʾʱ��bitmapʵ��
			img = null;
		}										  // ��ȡͼƬ����
		img = decodeBitmap(path, display_width, display_height); 
		photo.setImageBitmap(img);                // ��ʾͼƬ
	}

	/**
	 * ��path�л�ȡͼƬ��Ϣ
	 */
	public static Bitmap decodeBitmap(String path, int width, int height) {
		BitmapFactory.Options op = new BitmapFactory.Options();
		op.inJustDecodeBounds = true;
		Bitmap bmp;
		bmp = BitmapFactory.decodeFile(path, op); // ����ȡ�ߴ���Ϣ
		// ��ȡ������С
		int wRatio = (int) Math.ceil((double) op.outWidth / width);
		int hRatio = (int) Math.ceil((double) op.outHeight / height);
		// �������ָ����С������С��Ӧ�ı���
		if (wRatio > 1 && hRatio > 1) {
			if (wRatio > hRatio) {
				op.inSampleSize = wRatio;
			} else {
				op.inSampleSize = hRatio;
			}
		}
		op.inJustDecodeBounds = false;
		bmp = BitmapFactory.decodeFile(path, op); //��ȡ����ͼƬ���ݵ�bitmapʵ��
		return bmp;
	}

}

