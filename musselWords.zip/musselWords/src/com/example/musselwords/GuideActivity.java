package com.example.musselwords;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.Window;

public class GuideActivity extends FragmentActivity{
	
	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.fragment_guide);
		Intent intent = getIntent();
		
		FragmentManager fm = getSupportFragmentManager();
		FragmentTransaction ft = fm.beginTransaction();
		
		if(intent.getStringExtra("a") == null){
			RegisterFragment register = new RegisterFragment();
			if(intent.getStringExtra("userID")!= null){
				Bundle bundle = new Bundle();
				bundle.putString("userID", intent.getStringExtra("userID"));
				register.setArguments(bundle);
			}
			ft.add(R.id.guide_container,register).commit();
		}else{
//			�����¼ҳ��
			if(intent.getStringExtra("a").equals("a")){
				SharedPreferences sp = this.getSharedPreferences("userID",Context.MODE_PRIVATE);
				String userID = sp.getString("userID", "");
//				����
				BookFragment book = new BookFragment();
				Bundle bundle = new Bundle();
				bundle.putString("userID", userID);
				book.setArguments(bundle);
				ft.add(R.id.guide_container,book).commit();
			}else{
//				�����¼ҳ��
				LoginFragment login = new LoginFragment();
				ft.add(R.id.guide_container,login).commit();
			}
		}
	}
}
