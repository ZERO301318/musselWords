package com.example.musselwords;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import data.StateManage;
import data.UserManage;
import data.WordsManage;

import android.content.res.Resources;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class DictationFragment extends Fragment implements OnClickListener,OnInitListener{

	private TextToSpeech tts;
	
	private TextView rate,max;
	private EditText input;
	private Button start;
	private LinearLayout container;

	private WordsManage words;
	private UserManage user;
	private StateManage stateManager;
	private Cursor cursor;
	private int bookID;//词书
	private String userID;
	
	private int num;//选择的听写数量
	private int reviewedNum;//复习过的单词数
	private String[] answer;//我的答案
	private HashMap<Integer, Integer> hash = new HashMap<Integer, Integer>();
	
	private String str;
	private Handler handler;
	private Runnable run;
	private int p,wordID;
	
//	刷新bookID
	@Override
	public void onResume() {
//		获取用户词书ID
		bookID = user.getBookID(userID);
		start.setClickable(true);
		initial();
		super.onResume();
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_dictation,container, false);
//		绑定控件
		bindWidgets(view);

//		取参数
		Bundle bundle = getArguments();
		if(bundle != null ){
			userID = bundle.getString("userID");
		}
		
//		初始化
		words = new WordsManage(getActivity());
		user = new UserManage(getActivity());
		stateManager = new StateManage(getActivity());
		tts = new TextToSpeech(getActivity(), this);
//		获取用户词书ID
		bookID = user.getBookID(userID);
		start.setClickable(true);
		initial();
		return view;
	}
	
	private void initial(){
//		获得用户已背数量
		reviewedNum = stateManager.getNum(userID);
		Resources res = getResources();
		if(reviewedNum == 0){
			Toast.makeText(getActivity(), res.getString(R.string.zero), Toast.LENGTH_SHORT).show();
			start.setClickable(false);
		}else if(reviewedNum == 1){
			max.setText(res.getString(R.string.theOne));
		}else{
			max.setText("(1~"+reviewedNum+")");
		}
	}
	
	private void bindWidgets(View view){
		start = (Button)view.findViewById(R.id.start);
		input = (EditText)view.findViewById(R.id.num);
		rate = (TextView)view.findViewById(R.id.rightRate);
		max = (TextView)view.findViewById(R.id.max);
		container = (LinearLayout)view.findViewById(R.id.answers);
		start.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		start.setClickable(false);
		container.removeAllViews();
		rate.setText("");
		p = 0;
		Resources res = getResources();
		if(!input.getText().toString().equals("")){
//			得到输入的数量
			num = Integer.parseInt(input.getText().toString());
			
//			获取用户相应词书ID的所有单词
			cursor = words.getWords(num, bookID);
			answer = new String[num];
//			判断输入格式是否正确
			if(num > 0 && num <= reviewedNum){
//				开始听写
				startPlay();
				addWidget();
				p++;
				runTask();
			}else{
				start.setClickable(true);
				Toast.makeText(getActivity(), res.getString(R.string.wrong_input)+reviewedNum+" "+res.getString(R.string.end), Toast.LENGTH_SHORT).show();
			}
		}else{
			start.setClickable(true);
			Toast.makeText(getActivity(), res.getString(R.string.input_empty), Toast.LENGTH_SHORT).show();
		}
	}
	
//	添加输入框
	public void addWidget(){
		EditText edit = new EditText(getActivity());
		edit.setFocusable(true);
		edit.requestFocus();
		edit.setId(p);
		container.addView(edit);
	}
	
//	显示成绩
	public void addResult(int sum){
		Resources res = getResources();
		String spell;
		for(int i=0; i<num; i++){
//			获取单词拼写
			spell = words.getSpell(hash.get(i)).toLowerCase();
			if(getStatue(answer[i], spell) == 0){
				TextView wrong = new TextView(getActivity());
				TextView right = new TextView(getActivity());
				LinearLayout liner = new LinearLayout(getActivity());
				liner.setOrientation(LinearLayout.HORIZONTAL);
				wrong.setText(res.getString(R.string.wrong)+answer[i]);
				wrong.setTextColor(res.getColor(R.color.red));
				right.setText(" ,"+res.getString(R.string.right)+spell);
				liner.addView(wrong);
				liner.addView(right);
				container.addView(liner);
			}	
		}
		rate.setText(res.getString(R.string.rate)+String.valueOf(((float)sum)/answer.length*100)+"%");
		rate.setTextColor(res.getColor(R.color.default_green));
//		判断是否全对
		if(container.getChildCount() == 0){
			Toast.makeText(getActivity(), res.getString(R.string.all_right), Toast.LENGTH_SHORT).show();
		}else{
			Toast.makeText(getActivity(), res.getString(R.string.has_Fault)+" "+(answer.length-sum)+" "+res.getString(R.string.unit), Toast.LENGTH_SHORT).show();
		}
	}
	
//	获得最终结果
	public int getResult(){
		Cursor tmp;
		int status;
		String spell;
		int sum = 0;
		
		TextView accurancy;
		Resources res = getResources();
		
		for(int i=0 ; i<num; i++){
			View v = container.getChildAt(i);
			EditText e = (EditText)v.findViewById(i);
			if(e.getText() != null){
				answer[i] = e.getText().toString().toLowerCase();
			}else{
				answer[i] = "";
			}
//			获取单词拼写
			spell = words.getSpell(hash.get(i)).toLowerCase();
			status = getStatue(answer[i],spell);
			if(status == 2){
				sum++;
			}
//			更新状态
			stateManager.update(hash.get(i), status,true);
		}
		return sum;
	}
	
//	比较答案是否正确
	public int getStatue(String a, String b){
		int status;
		if(a.equals(b)){
			status = 2;
		}else{
			status = 0;
		}
		
		return status;
	}
	
	/**
	 * 每隔7s报一个单词并新增并跳转下一个输入框
	 */
	public void runTask(){
		handler = new Handler();
		run = new Runnable() {
			@Override
			public void run() {
				if(p == num){
					handler.removeCallbacks(run);
					int sum = getResult();
					container.removeAllViews();
					addResult(sum);
					start.setClickable(true);
				}else{
					handler.postDelayed(this,7000);
					startPlay();
					addWidget();
				}
				p++;
			}
		};
		handler.postDelayed(run, 7000);
	}
	
	/**
	 * 发出声音
	 * @param str
	 */
	public void startPlay(){
		
		str = cursor.getString(cursor.getColumnIndex("SPELLING"));
		wordID = cursor.getInt(cursor.getColumnIndex("WORD_ID"));
		hash.put(p, wordID);
		/**
		 * 更新听写次数***************************
		 */
		
//		设置音量
		tts.setPitch(0.0f);
		tts.speak(str,TextToSpeech.QUEUE_FLUSH, null);
//		判断是否为最后一个单词
		if((p+1) < num){
			cursor.moveToNext();
		}
	}
	
	@Override
	public void onInit(int status) {
		if(status == TextToSpeech.SUCCESS){
			int result = tts.setLanguage(Locale.US);
			if(result == TextToSpeech.LANG_NOT_SUPPORTED){
				Log.d("WRONG", "FAILED!");
			}
		}
	}

	@Override
	public void onStop() {
		super.onStop();
		tts.stop();
		tts.shutdown();
	}

}
