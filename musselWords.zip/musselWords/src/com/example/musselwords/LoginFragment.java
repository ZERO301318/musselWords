package com.example.musselwords;

import data.MyHelper;
import data.UserManage;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.UserManager;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginFragment extends Fragment implements OnClickListener{
	
	private UserManage userManager;
	
	private EditText userID,userPass;
	
	private View view;
	private Button login,toResign;
	
	@Override
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_login, container,false);
		
		userManager = new UserManage(getActivity());
		bindWidget(view);
		
		return view;
	}

	
//	�󶨿ؼ�
	public void bindWidget(View view){
		userID = (EditText)view.findViewById(R.id.userID);
		userPass = (EditText)view.findViewById(R.id.userPass);
		
		login = (Button)view.findViewById(R.id.login);
		toResign = (Button)view.findViewById(R.id.toResign);
		
		login.setOnClickListener(this);
		toResign.setOnClickListener(this);
		
	}

	@Override
	public void onClick(View v) {

		String id = String.valueOf(userID.getText());
		String pass = String.valueOf(userPass.getText());
		
		switch (v.getId()) {
		case R.id.login:
			if(id.equals("")){
				Toast.makeText(getActivity(), getResources().getString(R.string.userID_empty), Toast.LENGTH_SHORT).show();
			}else if(pass.equals("")){
				Toast.makeText(getActivity(), getResources().getString(R.string.pass_empty), Toast.LENGTH_SHORT).show();
			}else{
//				����������ʱ
				if(!isNumeric0(id)){
					Cursor tmp = userManager.getAll(null, id);
					id = tmp.getString(tmp.getColumnIndex("USER_ID"));
				}
				if(userManager.checkUser(id, pass,true)){
					Intent intent = new Intent(getActivity(),MainActivity.class);
					startActivity(intent);
					intent.putExtra("userID", id);
					getActivity().finish();
					Toast.makeText(getActivity(), getResources().getString(R.string.login_success), Toast.LENGTH_SHORT).show();
				}else{
					selectType();
				}
			}
			break;
		case R.id.toResign:
			Intent intent = new Intent(getActivity(),GuideActivity.class);
			startActivity(intent);
			getActivity().finish();
			break;
		default:
			break;
		}
		
	}
	
//	��¼ʧ����ʾ
	public void selectType(){
		Builder builder = new Builder(getActivity());
		final AlertDialog dialog = builder.create();
		View view = View.inflate(getActivity(), R.layout.wrong_dialog,null);
		TextView confirm = (TextView)view.findViewById(R.id.cf);
		
		confirm.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});
		dialog.setView(view);
		dialog.show();
	}
	
//	�ж��Ƿ�Ϊ����
	public static boolean isNumeric0(String str){
		for(int i=str.length();--i>=0;){
			int chr=str.charAt(i);
			if(chr<48 || chr>57){
				return false;
			}
		}
		return true;
	}
	

}
