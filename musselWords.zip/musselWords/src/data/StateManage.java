package data;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class StateManage extends Manager{
	
	public StateManage(Context ct) {
		super(ct);
	}
	/**
	 * 
	 * @param userID
	 * @return true == ����ո��¹�
	 */
	public boolean isNew(String userID){
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("select * from STATE where REVIEW_TIMES>0", null);
		if(cursor.getCount() == 0){
			db.close();
			return true;
		}
		db.close();
		return false;
	}
	
	public int getNum(String userID){
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("select * from STATE where REVIEW_TIMES>0 and USER_ID='"+userID+"'", null);
		int sum = cursor.getCount();
		db.close();
		return sum;
	}
	
//	ѡ�������ѱ����ʵ�����
	public int getMyWords(String userID){
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("select * from STATE where KNOW_STATUE = 2 and USER_ID = '"+userID+"'", null);
		int sum = cursor.getCount();
		db.close();
		return sum;
	}
	
//	��մ��û�������
	public void deleteAll(String userID){
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		db.execSQL("delete from STATE where USER_ID ='"+userID+"'");
		db.close();
	}
	
//	��ʼ������û���state��
	public boolean initial(String userID,Cursor cursor){
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		int wordID;
		try{
			do{
				wordID = cursor.getInt(cursor.getColumnIndex("WORD_ID"));
				db.execSQL("insert into STATE ('USER_ID','WORD_ID') values('"+userID+"',"+wordID+")");
			}while(cursor.moveToNext());
		}catch(Exception e){
			System.out.print(e.getMessage());
			return false;
		}finally{
			db.close();
		}
		return true;
	}
	
//	����words״̬
	public void update(int wordID,int state,boolean bool){
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		SQLiteDatabase dbReader = dbHelper.getReadableDatabase();
		String sql;
		int times;
		try{
			Cursor tmp = dbReader.rawQuery("select * from STATE where WORD_ID= "+wordID, null);
			tmp.moveToFirst();
			
			if(bool){
				times = tmp.getInt(tmp.getColumnIndex("LISTENED_TIMES"))+1;
				sql = "update STATE set LISTENED_TIMES = "+times+", KNOW_STATUE = "+state+" where WORD_ID= "+wordID+"";
			}else{
				times = tmp.getInt(tmp.getColumnIndex("REVIEW_TIMES"))+1;
				sql = "update STATE set REVIEW_TIMES = "+times+", KNOW_STATUE = "+state+" where WORD_ID= "+wordID+"";
			}
//			ִ��
			db.execSQL(sql);
		}catch(Exception e){
			System.out.print(e.getMessage());
			Log.d("wong", e.getMessage());
		}finally{
			db.close();
			dbReader.close();
		}
	}
	
	
}
