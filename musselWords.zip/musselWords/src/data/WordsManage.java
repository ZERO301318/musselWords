package data;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class WordsManage extends Manager{

	private Cursor cursor;
	
	public WordsManage(Context ct) {
		super(ct);
	}
	
	public Cursor getAll(int bookID,boolean bool){
		SQLiteDatabase dbReader = dbHelper.getReadableDatabase();
		try{
//			ѡȡδ�����ĵ���
			if(bool){
				cursor = dbReader.rawQuery("select * from WORDS,STATE where BOOK_ID = "+bookID+" and STATE.REVIEW_TIMES=0 and WORDS.WORD_ID=STATE.WORD_ID", null);	
			}else{
				cursor = dbReader.rawQuery("select * from WORDS where BOOK_ID = "+bookID, null);
			}
			cursor.moveToFirst();
		}catch(Exception e){
			System.out.print(e.getMessage());
			Log.d("WRONG", e.getMessage());
			return null;
		}finally{
			dbReader.close();
		}
		return cursor;
	}
	
//	����õ����е��ʵ�ָ��
	public Cursor getWords(int num,int bookID){
		SQLiteDatabase dbReader = dbHelper.getReadableDatabase();
		try{
//			ѧ�򱳹����Ҵ������ѡ��ָ������
			cursor = dbReader.rawQuery("select * from WORDS,STATE where BOOK_ID ="+bookID+" and WORDS.WORD_ID=STATE.WORD_ID and STATE.REVIEW_TIMES>0 order by random() limit "+num+"", null);
			cursor.moveToFirst();
		}catch(Exception e){
			System.out.print(e.getMessage());
			return null;
		}finally{
			dbReader.close();
		}
		return cursor;
	}
	
	public String getSpell(int wordID){
		String spell = "";
		SQLiteDatabase dbReader = dbHelper.getReadableDatabase();
		try{
			cursor = dbReader.rawQuery("select * from WORDS where WORD_ID="+wordID, null);
			cursor.moveToFirst();
			spell = cursor.getString(cursor.getColumnIndex("SPELLING"));
		}catch(Exception e){
			System.out.print(e.getMessage());
			return spell;
		}finally{
			dbReader.close();
		}
		return spell;
	}
	
}
