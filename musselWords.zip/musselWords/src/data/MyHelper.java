package data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyHelper extends SQLiteOpenHelper{
	
	public MyHelper(Context context) {
		super(context, "infos", null, 1);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {

		try{
			/**
			 * �û�
			 * user_id ע��ʱ���ɲ��ظ���6λ������Ϊid
			 * is_login 0:δ��¼ 1:�ѵ�¼
			 */
			String userSql = "CREATE TABLE USER(USER_ID TEXT PRIMARY KEY, NAME TEXT NOT NULL, PASS TEXT NOT NULL, USER_HEAD BLOB NOT NULL, BOOK_ID INTEGER, LEARNED_NUM INTEGER DEFAULT 0, IS_LOGIN TINYINT NOT NULL DEFAULT 0)";
//			����
			String booksSql = "CREATE TABLE BOOKS(BOOK_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,NAME TEXT NOT NULL, SUM_WORD INTEGER NOT NULL)";
//			���ʱ�
			String wordsSql = "CREATE TABLE WORDS(WORD_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, SPELLING TEXT NOT NULL, IPA TEXT NOT NULL, MEANNING TEXT NOT NULL, BOOK_ID INTEGER NOT NULL)";
			
			/**
			 * �û���ÿ�����ʵ�ѧϰ���	
			 * IS_LISTENED 0:û��д�� 1:��д��
			 * know_state 0:����  1:ģ��  2:��ʶ 3:��� 
			 */
			String stateSql = "CREATE TABLE STATE(USER_ID INTEGER NOT NULL, WORD_ID INT NULL, REVIEW_TIMES TINYINT NOT NULL DEFAULT 0, LISTENED_TIMES INTEGER NOT NULL DEFAULT 0, KNOW_STATUE TINYINT NOT NULL DEFAULT 0)";
			
			db.execSQL(userSql);
			db.execSQL(booksSql);
			db.execSQL(wordsSql);
			db.execSQL(stateSql);
			
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	}
}
