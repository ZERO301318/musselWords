package data;

import java.io.ByteArrayOutputStream;
import java.util.Random;

import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap.CompressFormat;
import android.util.Log;

public class Manager{
	protected MyHelper dbHelper;
	protected Context ct;
	private Cursor cursor;
	
//	�õ�MyHelper��ʵ��
	public  Manager(Context ct) {
		dbHelper = new MyHelper(ct);
		this.ct = ct;
	}
	
//	
	/**
	 * true == ��Ϊ��
	 * @param tableName
	 * @return
	 */
	public boolean isEmpty(String tableName){
		SQLiteDatabase dbReader = dbHelper.getReadableDatabase();
		try{
			cursor = dbReader.rawQuery("select * from "+tableName, null);
			if(cursor.getCount() == 0 || !cursor.moveToFirst()) {
				return true;
			}
		}catch(Exception e){
			Log.d("a", e.getMessage());
		}
		dbReader.close();
		return false;
	}
	
//	������ɾ�λ���˺�
	public String getID(){
		UserManage userManage = new UserManage(ct);
		Random random = new Random();
		String result = "";
		for(int i=0; i<9; i++){
			if(i == 0){
				result += random.nextInt(10);
				if(result.equals("0")){
					result = "1";
				}
			}else{
				result += random.nextInt(10);
			}
//			���id�Ƿ��ظ�
			if(i == 8 && !userManage.isRepeat(result,null,true)){
				i = -1;
			}
		}
		return result;
	}
//	��Դ�ļ�תblob
	public byte[] getData(int id){
		Resources res = ct.getResources();
		Bitmap bmp = BitmapFactory.decodeResource(res, id);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		bmp.compress(CompressFormat.PNG, 100, baos);
		return baos.toByteArray();
	}
	
//	ת bmp
	public Bitmap bytetToBmp(byte[] imgdata){
		Bitmap bmp = BitmapFactory.decodeByteArray(imgdata,0,imgdata.length);
		return bmp;
	}
}
