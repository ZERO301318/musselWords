package data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class UserManage extends Manager{
	private byte[] defaultImg;
	private Cursor cursor;
	
	public UserManage(Context ct) {
		super(ct);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * ���ע���û�ʱ�����Ƿ�ѡ��
	 * @return false == δ����ѡ�� 
	 */
	public boolean hasBookID(){
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		cursor = db.rawQuery("select * from USER where IS_LOGIN=1", null);
		cursor.moveToFirst();
		if(cursor.getInt(cursor.getColumnIndex("BOOK_ID")) < 1){
			db.close();
			return false;
		}
		db.close();
		return true;
	}
	
	/**
	 * �ж��û��Ƿ��¼
	 * @param userID
	 * @return true == ��¼
	 */
	public boolean isLogin(){
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		cursor = db.rawQuery("select * from USER where IS_LOGIN = 1", null);
//		δ��¼ʱ
		if(cursor.getCount() == 0){
			db.close();
			return false;
		}
		db.close();
		return true;
	}

//	�����û��˺������Ƿ���ȷ
	public boolean checkUser(String userID,String pass,boolean bool){
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		try{
//			����¼ʱ
			if(bool){
				cursor = db.rawQuery("select * from USER where USER_ID = '"+userID+"' and PASS = '"+pass+"'", null);
				if(cursor.getCount() == 0){
					db.close();
					return false;
				}else{
					SQLiteDatabase up = dbHelper.getWritableDatabase();
					up.execSQL("update USER set IS_LOGIN = 1 where USER_ID = '"+userID+"'");
					up.close();
				}
			}else{
				cursor = db.rawQuery("select * from USER where USER_ID='"+userID+"'and PASS = '"+pass+"'", null);
				if(cursor.getCount() == 0){
					db.close();
					Log.d("wrong", "select * from USER where USER_ID='"+userID+"'and PASS = '"+pass+"'");
					return false;
				}else{
					Log.d("success", "select * from USER where USER_ID='"+userID+"'and PASS = '"+pass+"'");
				}
			}
		}catch(Exception e){
			Log.d("EXCEPTION", e.getMessage());
			return false;
		}finally{
			db.close();
		}
		return true;
	}
	
	/**
	 * bool = false === ����ʱ
	 * @param userID
	 * @param userName
	 * @param bool
	 * @return
	 */
	public boolean isRepeat(String userID,String userName,boolean bool){
		SQLiteDatabase dbReader = dbHelper.getReadableDatabase();
		String sql;
//		������ϵ��ʱ
		if(bool){
//			����IDʱ�ж��Ƿ��������˺��ظ�
			if(userID != null){
				sql = "select * from USER where USER_ID='"+userID+"'";
			}else{
				sql = "select * from USER where NAME ='"+userName+"'";	
			}
			cursor = dbReader.rawQuery(sql,null);
			cursor.moveToFirst();
			if(cursor.getCount() != 0){
				dbReader.close();
				return false;
			}
		}else{
			sql = "select * from USER where USER_ID !='"+userID+"'";
			cursor = dbReader.rawQuery(sql,null);
			cursor.moveToFirst();
			while(cursor.moveToNext()){
				if(userName == cursor.getString(cursor.getColumnIndex("NAME"))){
					dbReader.close();
					return false;
				}
			}
		}
			
		return true;
	}
	
	
	public boolean insert(String userName,String pass, byte[] userHead){
		SQLiteDatabase dbWriter = dbHelper.getWritableDatabase();
		try{
			ContentValues values = new ContentValues();
			values.put("USER_ID",getID());
			values.put("NAME",userName);
			values.put("PASS", pass);
			values.put("USER_HEAD", userHead);
			dbWriter.insert("USER", null, values);
		}catch(Exception e){
			System.out.print(e.getMessage());
			return false;
		}finally{
			dbWriter.close();
		}
		return true;
	}
	
	public boolean update(String userID,String userName,String pass, byte[] userHead){
		SQLiteDatabase dbUpdate = dbHelper.getWritableDatabase();
		try{
			ContentValues values = new ContentValues();
			values.put("NAME",userName);
//			���޸������
			if(pass != null){
				values.put("PASS", pass);
			}
//			���޸�ͼƬ��
			if(userHead != null){
				values.put("USER_HEAD", userHead);
			}
			dbUpdate.update("USER", values, "USER_ID=?", new String[]{userID});
		}catch(Exception e){
			System.out.print(e.getMessage());
			return false;
		}finally{
			dbUpdate.close();
		}
		return true;
	}
	
	public Cursor getAll(String userID,String userName){
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		try{
			String sql = null;
			if(userID != null){
				sql = "select * from USER where USER_ID='"+userID+"'";
			}
			if(userName != null){
				sql = "select * from USER where NAME='"+userName+"'";
			}
			cursor = db.rawQuery(sql,null);
			cursor.moveToFirst();
		}catch(Exception e){
			System.out.print(e.getMessage());
			return null;
		}finally{
			db.close();
		}
		return cursor;
	}
	
	public int getBookID(String userID){
		int bookID;
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		cursor = db.rawQuery("select * from USER where USER_ID = '"+userID+"'", null);
		cursor.moveToFirst();
		bookID = cursor.getInt(cursor.getColumnIndex("BOOK_ID"));
		return bookID;
	}
	
}
