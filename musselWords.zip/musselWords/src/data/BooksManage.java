package data;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class BooksManage extends Manager{
	private Cursor cursor;
	
	public BooksManage(Context ct) {
		super(ct);
	}
	
	
	/**
	 * ���ÿһ���������еĵ�������
	 * @param i
	 * @return
	 */
	public int numOfWords(int i){
		int num = 0;
		SQLiteDatabase dbReader = dbHelper.getReadableDatabase();
		try{
			cursor = dbReader.rawQuery("select * from WORDS where BOOK_ID = "+i,null);
			cursor.moveToFirst();
			num = cursor.getCount();
		}catch(Exception e){
			System.out.print(e.getMessage());
		}finally{
			dbReader.close();	
		}
		return num;
	}
	
	public boolean insert(String book_name,int num){
		SQLiteDatabase dbWriter = dbHelper.getWritableDatabase();
		try{
			dbWriter.execSQL("insert into BOOKS ('NAME','SUM_WORD') values ('"+book_name+"','"+num+"')");
		}catch(Exception e){
			System.out.print(e.getMessage());
			return false;
		}finally{
			dbWriter.close();
		}
		return true;
	}
	
	public String getName(int id){
		String name = "";
		SQLiteDatabase dbReader = dbHelper.getReadableDatabase();
		try{
			cursor = dbReader.rawQuery("select * from BOOKS where BOOK_ID='"+id+"'", null);
			cursor.moveToFirst();
			if(cursor.getCount() != 0){
				name = cursor.getString(cursor.getColumnIndex("NAME"));
			} 
		}catch(Exception e){
			System.out.print(e.getMessage());
		}finally{
			dbReader.close();
		}
		return name;
	}
	

	
//	�����û��Ĵ���
	public boolean updateBookID(String userID,int bookID){
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		try{
//			���û�ѡ�����飬ѡ����һ��������ԭʼ����ļ������
			db.execSQL("update USER set BOOK_ID = "+bookID+" where USER_ID='"+userID+"'");
		}catch(Exception e){
			System.out.print(e.getMessage());
			return false;
		}finally{
			db.close();
		}
		return true;
	}
	
}
